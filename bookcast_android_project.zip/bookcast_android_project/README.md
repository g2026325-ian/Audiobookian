# BookCast Android project

An Android Studio project wrapping the BookCast library in a native Android WebView and using Android's built-in Text-to-Speech engine for narration.

## Build an APK
1. Install **Android Studio** on a computer (Android SDK Platform 35 recommended).
2. Extract this project ZIP.
3. In Android Studio, choose **Open** and select the extracted `bookcast_android_project` folder.
4. Allow Gradle sync/downloads to finish.
5. Use **Build → Build APK(s)**. Android Studio will show a link to the debug APK, typically under `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer that APK to your Android phone and install it. You may need to allow installing apps from that file manager.

## Current capabilities
- Local bookshelf dashboard, author/status organization, reading progress, manual book entry, and local browser storage.
- Native Android text-to-speech using the phone's installed voice. Speech speed and pitch controls are passed to Android TTS.
- Import TXT, Markdown, and HTML files from the in-app file picker.
- No account or server required for the Android app's basic features; library data stays on the device.

## Current limitations
- This is the **Android Studio source project**, not a precompiled APK. This environment has Java but no Android SDK/Gradle installation, so an APK could not be compiled here.
- Direct import of PDF, EPUB, and DOCX is not yet implemented in this Android build. You can paste extracted text through **Add a book manually**; the desktop/web version supports more formats through its local Python parser.
- Android TTS uses voices installed on the phone. Offline narration depends on whether an offline voice is installed in Android's text-to-speech settings.
- This project uses Android Gradle Plugin 8.7.3 and Kotlin 2.0.21; Android Studio needs internet for its first dependency sync.
